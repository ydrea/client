import React from 'react';
// import s from './footer.module.scss';

//
export const Footer = () => {
  return (
    <div //className={s.c}
    >
      {/* da)
      <a className={s.a} href="https://github.com/ydrea">
        ydrea
      </a>
      (mnation */}
      impressum{' '}
    </div>
  );
};
