import React from 'react';

function Projects() {
  return <div style={{ color: 'black' }}>Projects</div>;
}
export default Projects;
