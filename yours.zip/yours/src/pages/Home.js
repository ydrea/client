import React from 'react';
import './Home.css';
import { transition } from '../transition';
function Home() {
  return <div className="home-container">Home</div>;
}

export default Home;
