import React from 'react';
// import { transition } from '../transition';

function Contact() {
  return (
    <div style={{ color: 'black' }} id="contact">
      Contact
    </div>
  );
}

export default Contact;
