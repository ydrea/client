import React from 'react';
import { transition } from '../transition';
function About() {
  return <div>About</div>;
}

export default transition(About);
